# 23391WebTAssignment
Webtech assignment1. It is form validation using Html, css and javascript.
~ Muheto Songa Cedrick
